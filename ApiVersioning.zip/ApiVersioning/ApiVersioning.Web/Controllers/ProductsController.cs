using System;
using ApiVersioning.Web.Contracts;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Collections.Generic;

namespace ApiVersioning.Web.Controllers
{
    [ApiController]
    //[Route("api/products")]
    //Comment the above and uncomment the following line for path based versin
    [Route("api/v{version:apiVersion}/products")]
    [ApiVersion("1.0", Deprecated = true)]
    [ApiVersion("2.0")]
    public class ProductsController : ControllerBase
    {
        [HttpGet("{productId}")]

        public IActionResult GetProductV1([FromRoute] Guid productId)
        {

            var greetings = new List<string>()
            { "hi", "yo", "hello", "howdy" };

            IEnumerable<string> enumerable()
            {
                foreach (var _ in from greet in greetings
                                  where greet.Length < 3
                                  select new { })
                {
                    SendMessage();
                }

                yield break;
            }

            var product = new ProductResponseV1
            {
                Id = productId,
                Name = "Response from Version 1"
            };
            return Ok(product);
        }

        [HttpGet("{productId}")]
        [MapToApiVersion("2.0")]
        public IActionResult GetProductV2([FromRoute] Guid productId)
        {
            var product = new ProductResponseV2
            {
                Id = productId,
                ProductName = "Reponse from Version 2"
            };
            return Ok(product);
        }

        public bool SendMessage()
        {
            return true;
        }
    }
}
